#pragma once

#include <glm/glm.hpp>
#include <glm/gtx/quaternion.hpp>

namespace Stardust::Math {
	using glm::quat;
	/*
		I don't normally use quaternions, but maybe add utils here later?
	*/
}